package com.doramastudio.mobile

import android.net.Uri
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { DoramaStudioApp() } }
    fun buildShorts(uri: Uri, sceneCount: Int, sceneSeconds: Int, onStatus: (String) -> Unit) {
        val outputDir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: run { onStatus("Не удалось открыть папку видео"); return }
        val output = java.io.File(outputDir, "DoramaShorts_${System.currentTimeMillis()}.mp4")
        val items = (0 until sceneCount).map { index ->
            val startMs = index * sceneSeconds * 1000L
            val endMs = startMs + sceneSeconds * 1000L
            val mediaItem = MediaItem.Builder().setUri(uri).setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setStartPositionMs(startMs).setEndPositionMs(endMs).build()).build()
            EditedMediaItem.Builder(mediaItem).build()
        }
        val sequence = EditedMediaItemSequence.Builder().addItems(items).build()
        val composition = Composition.Builder(sequence).build()
        val transformer = Transformer.Builder(this).setVideoMimeType(MimeTypes.VIDEO_H264).setAudioMimeType(MimeTypes.AUDIO_AAC).addListener(object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) { onStatus("ГОТОВО! Видео сохранено: ${output.name}") }
            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) { onStatus("Ошибка монтажа: ${exportException.message ?: "неизвестная ошибка"}") }
        }).build()
        onStatus("Монтаж идёт… не закрывайте приложение")
        transformer.start(composition, output.absolutePath)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun DoramaStudioApp() {
    val activity = androidx.compose.ui.platform.LocalContext.current as MainActivity
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("Выберите видео") }
    var scenes by remember { mutableIntStateOf(10) }
    var seconds by remember { mutableIntStateOf(5) }
    var working by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) { videoUri = uri; status = "Видео выбрано. Готово к монтажу." } }
    MaterialTheme { Scaffold(topBar = { TopAppBar(title = { Text("Dorama Studio Mobile v2") }) }) { padding ->
        LazyColumn(modifier = Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Text("Автоматический монтаж Shorts", style = MaterialTheme.typography.headlineSmall); Text("Настоящая нарезка и склейка видео. Пока без озвучки, распознавания и перевода.") }
            item { Button(onClick = { picker.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth(), enabled = !working) { Text("ВЫБРАТЬ ВИДЕО") } }
            item { Text(status) }
            item { Text("Количество сцен: $scenes"); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button(onClick = { scenes = (scenes - 1).coerceAtLeast(1) }, enabled = !working) { Text("-") }; Button(onClick = { scenes = (scenes + 1).coerceAtMost(20) }, enabled = !working) { Text("+") } } }
            item { Text("Длительность сцены: $seconds сек."); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button(onClick = { seconds = (seconds - 1).coerceAtLeast(3) }, enabled = !working) { Text("-") }; Button(onClick = { seconds = (seconds + 1).coerceAtMost(8) }, enabled = !working) { Text("+") } } }
            item { Button(onClick = { videoUri?.let { working = true; activity.buildShorts(it, scenes, seconds) { msg -> status = msg; if (msg.startsWith("ГОТОВО") || msg.startsWith("Ошибка")) working = false } } }, enabled = videoUri != null && !working, modifier = Modifier.fillMaxWidth()) { Text(if (working) "МОНТАЖ ИДЁТ…" else "СОБРАТЬ SHORTS") } }
            item { Text("Версия 2.0: реальная нарезка и склейка. Следующим этапом добавим 9:16, распознавание, перевод и субтитры.") }
        }
    } }
}
